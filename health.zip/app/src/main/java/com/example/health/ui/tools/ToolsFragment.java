package com.example.health.ui.tools;

import android.app.DatePickerDialog;
import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import com.example.health.DatabaseHandler;
import com.example.health.MainActivity;
import com.example.health.R;

import java.util.Calendar;

public class ToolsFragment extends Fragment {

    private ToolsViewModel toolsViewModel;
    DatabaseHandler db;
    EditText name;
    TextView dob;
    RadioGroup gender;
    Calendar c;
    int birthDay;
    int birthMonth;
    int birthYear;
    String genderSubmit;
    String nameSubmit;
    DatePickerDialog dp;
    Button update;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        toolsViewModel =
                ViewModelProviders.of(this).get(ToolsViewModel.class);
        final View root = inflater.inflate(R.layout.fragment_tools, container, false);
        final TextView textView = root.findViewById(R.id.text_tools);

        name=root.findViewById(R.id.name);
        dob=root.findViewById(R.id.dob);
        gender=root.findViewById(R.id.gender);
        update=root.findViewById(R.id.update);

        db=new DatabaseHandler(this.getActivity());
        String info=userInfo();
        final String infoArray[]=info.split(",");
        final String dateOfBirth=infoArray[1]+"-"+infoArray[2]+"-"+infoArray[3];
        birthDay=Integer.parseInt(infoArray[1]);
        birthMonth=Integer.parseInt(infoArray[2]);
        birthYear=Integer.parseInt(infoArray[3]);

        toolsViewModel.getText().observe(this, new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
                textView.setText("Edit Profile");
                name.setText(infoArray[0]);
                dob.setText(dateOfBirth);

                if(infoArray[4].equals("Male"))
                {
                   RadioButton genderValue=root.findViewById(R.id.male);
                    genderValue.setChecked(true);
                }
                else if(infoArray[4].equals("Female")){
                   RadioButton genderValue=root.findViewById(R.id.female);
                    genderValue.setChecked(true);
                }

            }
        });
        dob.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                c= Calendar.getInstance();
                int day=c.get(Calendar.DAY_OF_MONTH);
                int month=c.get(Calendar.MONTH);
                int year=c.get(Calendar.YEAR);

                dp=new DatePickerDialog(getActivity(), new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int mYear, int mMonth, int mDay) {
                        dob.setText(mDay+"-"+ (mMonth+1) +"-"+mYear);
                        birthDay=mDay;
                        birthMonth=(mMonth+1);
                        birthYear=mYear;
                    }
                }, day, month, year);
                dp.show();
            }
        });

        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int selectedId = gender.getCheckedRadioButtonId();
                RadioButton genderValue = (RadioButton) root.findViewById(selectedId);
                genderSubmit = genderValue.getText().toString();

                name = (EditText) root.findViewById(R.id.name);
                nameSubmit = name.getText().toString();


                boolean isInserted = db.updateUser(nameSubmit, birthDay, birthMonth, birthYear, genderSubmit);
                if (isInserted == true){
                    Toast.makeText(getActivity(), "Profile Updated", Toast.LENGTH_LONG).show();

                }
                else
                    Toast.makeText(getActivity(),"Profile Not Updated",Toast.LENGTH_LONG).show();


            }
        });

        return root;
    }
    public String userInfo() {
        Cursor res = db.getUserData();

        StringBuffer buffer = new StringBuffer();
        while (res.moveToNext()) {
            buffer.append(res.getString(1)+"," );
            buffer.append(res.getString(2)+"," );
            buffer.append(res.getString(3)+"," );
            buffer.append(res.getString(4)+"," );
            buffer.append(res.getString(5) );
        }
        return buffer.toString();
    }

}