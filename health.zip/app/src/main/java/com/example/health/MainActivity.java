package com.example.health;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    TextView dob;
    Calendar c;
    DatePickerDialog dp;
    RadioGroup gender;
    RadioButton genderValue;
    Button register;
    EditText name;
    int birthDay;
    int birthMonth;
    int birthYear;
    String genderSubmit;
    String nameSubmit;
    DatabaseHandler db;
    float initialSteps=32;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        db=new DatabaseHandler(this);

        redirect();

        dob=(TextView)findViewById(R.id.dob);
        gender=(RadioGroup)findViewById(R.id.gender);
        register =(Button)findViewById(R.id.update);
        dob.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                c=Calendar.getInstance();
                int day=c.get(Calendar.DAY_OF_MONTH);
                int month=c.get(Calendar.MONTH);
                int year=c.get(Calendar.YEAR);

                dp=new DatePickerDialog(MainActivity.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int mYear, int mMonth, int mDay) {
                        dob.setText(mDay+"-"+ (mMonth+1) +"-"+mYear);
                        birthDay=mDay;
                        birthMonth=(mMonth+1);
                        birthYear=mYear;
                    }
                }, day, month, year);
                dp.show();
            }
        });
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int selectedId = gender.getCheckedRadioButtonId();
                genderValue = (RadioButton) findViewById(selectedId);
                genderSubmit = genderValue.getText().toString();

                name = (EditText) findViewById(R.id.name);
                nameSubmit = name.getText().toString();


                boolean isInserted = db.insertUser(nameSubmit, birthDay, birthMonth, birthYear, genderSubmit,initialSteps);
                if (isInserted == true){
                    Toast.makeText(MainActivity.this, "Data Inserted", Toast.LENGTH_LONG).show();
                    openDashboard();
            }
                else
                    Toast.makeText(MainActivity.this,"Data not Inserted",Toast.LENGTH_LONG).show();


            }
        });
    }

    public void openDashboard()
    {
        Intent Dashboard=new Intent(this,Hms.class);
        startActivity(Dashboard);
    }
    public void redirect()
    {
        Cursor res=db.getUserData();
        int count=res.getCount();
        if(count>0)
            openDashboard();
    }
    public void showValues()
    {
        Cursor res;
    }

}
