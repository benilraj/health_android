package com.example.health;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class goal extends AppCompatActivity {

    EditText steps;
    Button submit;
    DatabaseHandler db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_goal);
        steps=(EditText) findViewById(R.id.steps);
        submit=(Button)findViewById(R.id.submit);
        db = new DatabaseHandler(this);
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int step=Integer.parseInt(steps.getText().toString());
                db.updateSteps(step);
                Toast.makeText(goal.this,"Updated",Toast.LENGTH_LONG).show();
            }
        });
    }
}
