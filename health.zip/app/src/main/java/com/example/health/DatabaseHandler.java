package com.example.health;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DatabaseHandler extends SQLiteOpenHelper {
    public static final String DatabaseName="health";

    public DatabaseHandler(@Nullable Context context) {
        super(context, DatabaseName, null, 1);
        SQLiteDatabase db=this.getWritableDatabase();
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE user (id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT ,birthDay INTEGER,birthMonth INTEGER,birthYear INTEGER,gender TEXT,initialSteps REAL)");
        db.execSQL("CREATE TABLE bmi(id INTEGER PRIMARY KEY AUTOINCREMENT,date TEXT ,height INTEGER,weight INTEGER,bmivalue REAL,bmiresult TEXT)");
        db.execSQL("CREATE TABLE goal(id INTEGER ,steps INTEGER,taken INTEGER)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS user");
        db.execSQL("DROP TABLE IF EXISTS bmi");
        db.execSQL("DROP TABLE IF EXISTS goal");
        onCreate(db);
    }

    public void initialGoal()
    {
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues cv=new ContentValues();
        cv.put("id",1);
        cv.put("steps",0);
        cv.put("taken",0);
        db.insert("goal",null,cv);

    }

    public boolean insertUser(String name,int birthDay,int birthMonth,int birthYear,String gender,float initialSteps)
    {
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues cv=new ContentValues();
        cv.put("name",name);
        cv.put("birthDay",birthDay);
        cv.put("birthMonth",birthMonth);
        cv.put("birthYear",birthYear);
        cv.put("gender",gender);
        cv.put("initialSteps",initialSteps);
        long result=db.insert("user",null,cv);
        initialGoal();
        if (result == -1) {
            return false;
        }
        else
            return true;
    }
    public boolean insertBmi(String date,int height,int weight,float bmivalue,String bmiresult)
    {
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues cv=new ContentValues();
        cv.put("date",date);
        cv.put("height",height);
        cv.put("weight",weight);
        cv.put("bmivalue",bmivalue);
        cv.put("bmiresult",bmiresult);
        long result=db.insert("bmi",null,cv);
        if (result == -1) {
            return false;
        }
        else
            return true;
    }
    public boolean updateUser(String name,int birthDay,int birthMonth,int birthYear,String gender)
    {
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues cv=new ContentValues();
        cv.put("name",name);
        cv.put("birthDay",birthDay);
        cv.put("birthMonth",birthMonth);
        cv.put("birthYear",birthYear);
        cv.put("gender",gender);

        String whereClause = "id=?";
        String whereArgs[] = {"1"};
        long result=db.update("user",cv,whereClause,whereArgs);
        if (result == -1) {
            return false;
        }
        else
            return true;
    }

    public Cursor getUserData(){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor res=db.rawQuery("SELECT * FROM user WHERE id=1",null);
        return res;
    }
    public Cursor getBmiData(){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor res=db.rawQuery("SELECT * FROM bmi",null);
        return res;
    }
    public Cursor getGoal(){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor res=db.rawQuery("SELECT * FROM goal where id=1",null);
        return res;
    }
    public void updateTaken()
    {
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues cv=new ContentValues();
        cv.put("taken",27);
        String whereClause = "id=?";
        String whereArgs[] = {"1"};
        db.update("goal",cv,whereClause,whereArgs);
    }
    public void updateSteps(int steps)
    {
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues cv=new ContentValues();
        cv.put("steps",steps);
        String whereClause = "id=?";
        String whereArgs[] = {"1"};
        db.update("goal",cv,whereClause,whereArgs);
    }
}
