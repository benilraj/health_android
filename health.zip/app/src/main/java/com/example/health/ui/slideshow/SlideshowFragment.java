package com.example.health.ui.slideshow;

import android.app.DatePickerDialog;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import com.example.health.DatabaseHandler;
import com.example.health.MainActivity;
import com.example.health.R;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class SlideshowFragment extends Fragment {

    private SlideshowViewModel slideshowViewModel;
    EditText height;
    EditText weight;
    Button calculate;
    DatabaseHandler db;
    int age;
    String formattedDate;
    float bmiValue;
    String bmiResult;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        slideshowViewModel =
                ViewModelProviders.of(this).get(SlideshowViewModel.class);
        db=new DatabaseHandler(this.getActivity());
        View root = inflater.inflate(R.layout.fragment_slideshow, container, false);
        final TextView textView = root.findViewById(R.id.text_slideshow);
        height=(EditText) root.findViewById(R.id.height);
        weight=(EditText) root.findViewById(R.id.weight);
        calculate=(Button) root.findViewById(R.id.submit);
        String info=userInfo();
        db.updateTaken();
        final String infoArray[]=info.split(",");
        final int YOB=Integer.parseInt(infoArray[1].toString());
        age=2019-YOB;
        Date c = Calendar.getInstance().getTime();
        SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy");
        formattedDate = df.format(c);
        slideshowViewModel.getText().observe(getViewLifecycleOwner(), new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
                textView.setText(infoArray[0]+"\t \t \t Age:"+Integer.toString(age));
            }
        });
        calculate.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {
                int h=Integer.parseInt(height.getText().toString());
                int w=Integer.parseInt(weight.getText().toString());
                bmiResult=calculateBmi(h,w);
                Toast.makeText(getActivity().getApplicationContext(),bmiResult,Toast.LENGTH_SHORT).show();
                textView.setText(infoArray[0]+"\t \t \t Age:"+Integer.toString(age)+"\t \t \tBMI:"+bmiResult);

                boolean isInserted = db.insertBmi(formattedDate, h, w,bmiValue,bmiResult);
                if (isInserted == true){
                    Toast.makeText(getActivity(), "Bmi Inserted", Toast.LENGTH_LONG).show();
                }
                else
                    Toast.makeText(getActivity(),"Bmi not Inserted",Toast.LENGTH_LONG).show();

            }
        });
        return root;
    }
    public String calculateBmi(int height,int weight)
    {
        float meter=((float)height/100);
        float meterSquare=(meter*meter);
        float bmi= ((float)weight/(float)meterSquare);
        bmiValue= (float) (Math.round(bmi * 100.0) / 100.0);

        if(bmi<16)
            return "Severe Thinness";
        if(bmi>16.0 && bmi<17)
            return "Moderate Thinness";
        if(bmi>17.0 && bmi<18.4)
            return "Mild Thinness";
        if(bmi>18.4 && bmi<26.0)
            return "Normal";
        if(bmi>26.0 && bmi<30)
            return "OverWeight";
        if(bmi>31.0 && bmi<35.0)
            return "Obese class 1";
        if(bmi>35.0 && bmi<41)
            return "obese class 2";
        if(bmi>40)
            return "Mild Thinness";
        else
            return "Normal 2";

    }
    public String userInfo() {
        Cursor res = db.getUserData();
        StringBuffer buffer = new StringBuffer();
        while (res.moveToNext()) {
            buffer.append(res.getString(1)+"," );
            buffer.append(res.getString(4) );
        }
        return buffer.toString();
    }
}