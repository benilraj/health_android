package com.example.health.ui.home;

import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import com.example.health.DatabaseHandler;
import com.example.health.R;

public class HomeFragment extends Fragment {

    private HomeViewModel homeViewModel;
    DatabaseHandler db;
    Button bmiHistory;
    TextView goal;
    TextView taken;
    int age;
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        homeViewModel =
                ViewModelProviders.of(this).get(HomeViewModel.class);
        View root = inflater.inflate(R.layout.fragment_home, container, false);
        final TextView textView = root.findViewById(R.id.text_home);
        bmiHistory=root.findViewById(R.id.bmiHistory);
        goal=root.findViewById(R.id.textView4);
        taken=root.findViewById(R.id.textView3);
        db=new DatabaseHandler(this.getActivity());
        String info=userInfo();
        final String infoArray[]=info.split(",");
        final int YOB=Integer.parseInt(infoArray[1].toString());
        age=2019-YOB;
        goal.setText("Goal for this month:"+infoArray[2]);
        taken.setText("Steps taken this month:"+infoArray[3]);
        homeViewModel.getText().observe(this, new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
                textView.setText(infoArray[0]+"\t \t \t Age:"+Integer.toString(age));

            }
        });


        bmiHistory.setOnClickListener(
                new View.OnClickListener(){

                    @Override
                    public void onClick(View v) {
                        Cursor res= db.getBmiData();
                        if(res.getCount()==0){
                            showMessage("Error" ,"nothing found");
                            return;
                        }
                        else
                        {
                            StringBuffer buffer=new StringBuffer();
                            while(res.moveToNext()){
                                buffer.append(res.getString(1)+"\t  ");
                                buffer.append(res.getString(2)+"\t  ");
                                buffer.append(res.getString(3)+"\t    ");
                                buffer.append(res.getString(4)+"\t");
                                buffer.append(res.getString(5)+"\t");
                            }
                            showMessage("  Date   Height Weight Bmi Result",buffer.toString());
                        }
                    }
                }
        );


        return root;
    }

    public String userInfo() {
        Cursor res = db.getUserData();
        StringBuffer buffer = new StringBuffer();
        while (res.moveToNext()) {
            buffer.append(res.getString(1)+"," );
            buffer.append(res.getString(4)+"," );
        }
        Cursor res2 = db.getGoal();
        while (res2.moveToNext()) {
            buffer.append(res2.getString(1)+"," );
            buffer.append(res2.getString(2) );
        }
        return buffer.toString();
    }
    public void showMessage(String title,String message){
        AlertDialog.Builder builder=new AlertDialog.Builder(getActivity());
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();

    }
}