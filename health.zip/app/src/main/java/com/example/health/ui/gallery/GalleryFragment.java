package com.example.health.ui.gallery;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import com.example.health.DatabaseHandler;
import com.example.health.Hms;
import com.example.health.MainActivity;
import com.example.health.R;
import com.example.health.goal;

public class GalleryFragment extends Fragment implements SensorEventListener {
    DatabaseHandler db;
    private GalleryViewModel galleryViewModel;
    TextView tv_steps;
    SensorManager sensorManager;
    Boolean running=false;
    int initial_steps=0;
    int count=0;
    Button button;
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        db=new DatabaseHandler(this.getActivity());
        galleryViewModel =
                ViewModelProviders.of(this).get(GalleryViewModel.class);
        View root = inflater.inflate(R.layout.fragment_gallery, container, false);
        final TextView textView = root.findViewById(R.id.text_gallery);
        tv_steps=(TextView)root.findViewById(R.id.tv_steps);
        button=(Button)root.findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openDashboard();
            }
        });
        sensorManager=(SensorManager)getActivity().getSystemService(Context.SENSOR_SERVICE);
        galleryViewModel.getText().observe(this, new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
               // textView.setText("Step Counter");
            }
        });
        return root;
    }

    @Override
    public void onResume() {
        super.onResume();
        running=true;
        Sensor countSensor=sensorManager.getDefaultSensor(Sensor.TYPE_STEP_COUNTER);
        if(countSensor !=null){
            sensorManager.registerListener(this,countSensor,SensorManager.SENSOR_DELAY_UI);
        }else{
            Toast.makeText(this.getActivity(),"Sensor not Found!!",Toast.LENGTH_SHORT).show();

        }
    }

    @Override
    public void onPause() {
        super.onPause();
        running=false;
        //sensorManager.unregisterListener(this);
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if(running){
            tv_steps.setText(String.valueOf(event.values[0]-initial_steps)+" Steps");
        }

    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }
    public void openDashboard()
    {

        Intent Dashboard=new Intent(getActivity(), goal.class);
        startActivity(Dashboard);
    }
}